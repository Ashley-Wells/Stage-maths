# Stage maths

A hit factor calculator for IPSC. Enter what you know about a competitor's run
and it works out the rest, then tells you the time you need to beat them at
each level of accuracy.

Works offline once loaded, and installs to the home screen like an app.

## Use it

Open the published URL on your phone.

- **iOS** — open in Safari, tap Share, then Add to Home Screen
- **Android** — open in Chrome and tap Install when prompted

After the first load it runs entirely from the phone, so it works at a range
with no signal.

## What it does

- Minor and Major scoring
- Enter any two of time, hit factor and points; the third is calculated
- Tap pad for dropped points — starts from a clean run, so you only tap errors
- Target times for clean, one charlie, one delta, one no-shoot, one mike, and
  a no-shoot plus mike
- Time cost of each error, and a seconds-per-alpha pace figure on the clean row

## Scoring assumptions

Alpha 5. Minor: charlie 3, delta 1. Major: charlie 4, delta 2. A mike is the
10 point penalty plus the 5 point alpha you didn't get, so 15 down. A no-shoot
hit is 10 down on its own, or 25 if the round missed the target as well.

Check these against your region's current rules before trusting them.

## Publishing

Static files, no build step. Enable GitHub Pages under Settings → Pages, with
the source set to deploy from `main` and the folder set to `/ (root)`.
